
function onclick(a){
    newWindow=window.open("a",
                        toolbar=0,
                        statusbar=0,
                        locationbar=0);
                    }
 <p><a href="#" onclick="window.open('https://cloudflare-ipfs.com/ipfs/QmZz8ZKMhtc2LjQXDGMChr86jizosEQV9eF7UEMYaTino7', 'winname', 'directories=no,titlebar=no,toolbar=0,location=no,status=no,menubar=no,scrollbars=yes,resizable=no,width=800,height=600');return false;">Click here</a></p>