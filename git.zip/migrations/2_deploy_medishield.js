var Agent = artifacts.require("./Medishield.sol");

module.exports = function(deployer) {
  deployer.deploy(Agent);
};